# TypeScript 中的数据类型

*   数字（number）
*   字符串（string）
*   数组（Array）
*   元祖（tuple）
*   布尔（boolean）
*   枚举（enum）
*   任意（any）
*   null 和 undefined
*   never
*   void