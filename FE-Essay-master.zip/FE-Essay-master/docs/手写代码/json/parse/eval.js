function jsonParse(opt) {
  return eval(`(${opt})`);
}
